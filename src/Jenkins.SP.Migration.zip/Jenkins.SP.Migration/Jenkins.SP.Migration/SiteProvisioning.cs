﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core.Framework.Provisioning.Connectors;
using OfficeDevPnP.Core.Framework.Provisioning.Model;
using OfficeDevPnP.Core.Framework.Provisioning.ObjectHandlers;
using OfficeDevPnP.Core.Framework.Provisioning.Providers.Xml;
using System.Net;
using System.Security;
using System.Threading;
using System.IO;
using OSP = Microsoft.SharePoint.Client;

namespace Jenkins.SP.Migration
{
    public partial class SiteProvisioning : System.Windows.Forms.Form
    {

        string templateWebUrl = string.Empty;
        string targetWebUrl = string.Empty;
        string userName = string.Empty;
        string password = string.Empty;
        SecureString pwd = null;
        ProvisioningTemplate template = null;
        private const int CP_NOCLOSE_BUTTON = 0x200;

        string srcType = string.Empty;
        string targetType = string.Empty;
        bool srcPublish = false;
        bool targetPublish = false;

        public SiteProvisioning()
        {
            InitializeComponent();
        }
        
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        #region Events
        private void btn_extractApply_Click(object sender, EventArgs e)
        {

            //Excution Started Disable all controls
            DisableControls();

            //assign values
            if (webUrl.Text != string.Empty) templateWebUrl = webUrl.Text;
            if (targetWebURL.Text != string.Empty) targetWebUrl = targetWebURL.Text;
            if (txt_UserName.Text != string.Empty) userName = txt_UserName.Text;
            if (txt_Password.Text != string.Empty) password = txt_Password.Text;
            pwd = new SecureString();
            foreach (char c in password.ToCharArray()) pwd.AppendChar(c);

            //Required field validator
            bool isValid = requiredFiedlValidator(templateWebUrl, targetWebUrl, userName, password);
            if (!isValid) return;

            //Validate User access
            isValid = ValidateUser(templateWebUrl, targetWebUrl, userName, password);
            if (!isValid) return;

            if (srcPublish) { lbl_srcSiteType.Text = "Publishing Site"; lbl_srcSiteType.Refresh(); } else { lbl_srcSiteType.Text = "Non Publising Site"; lbl_srcSiteType.Refresh(); }
            if (targetPublish) { lbl_targetSiteType.Text = "Publishing Site"; lbl_targetSiteType.Refresh(); } else { lbl_targetSiteType.Text = "Non Publising Site"; lbl_targetSiteType.Refresh(); }
            if (srcPublish == targetPublish)
            {
                //Extract the Site
                template = GetProvisioningTemplate(templateWebUrl, userName, pwd);
                if (template != null)
                {
                    //Apply web Template to target Site
                    isValid = ApplyProvisioningTemplate(targetWebUrl, userName, pwd, template);
                    if (isValid)
                    {
                        //Migrate List Items
                        List<string> lists = new List<string>();
                        List<string> library = new List<string>();
                        List<string> sitepages = new List<string>();
                        
                        listAllListsandLibraries(templateWebUrl, userName, pwd, out lists, out library, out sitepages);
                        
                        string listname = string.Empty;
                        if (chk_IncludeLists.Checked)
                        {
                            for (int i = 0; i < lists.Count; i++)
                            {
                                int j = i + 1;
                                listname = lists[i];
                                Console.WriteLine("List : " + listname + " " + j.ToString() + " out of " + lists.Count);
                                CloneListItems(listname, templateWebUrl, targetWebUrl, userName, pwd);
                            }
                        }
                        string libraryname = string.Empty;
                        if (chk_includeLibraries.Checked)
                        {
                            for (int i = 0; i < library.Count; i++)
                            {
                                int j = i + 1;
                                libraryname = library[i];
                                Console.WriteLine("Library : " + libraryname + " " + j.ToString() + " out of " + library.Count);
                                CloneLibraryItems(libraryname, templateWebUrl, targetWebUrl, userName, pwd);
                            }
                        }

                        string sitepage = string.Empty;
                        if (chk_includePages.Checked)
                        {
                            for (int i = 0; i < sitepages.Count; i++)
                            {
                                int j = i + 1;
                                sitepage = sitepages[i];
                                Console.WriteLine("Pages : " + sitepage + " " + j.ToString() + " out of " + sitepages.Count);
                                CloneSitePages(templateWebUrl, sitepage, targetWebUrl, userName, pwd);
                            }
                        }
                    }
                }
                Console.WriteLine("Completed Sucessfully");
            }
            else
            {
                Console.WriteLine("Source and Target sites are different type...");
            }
            EnableControls();
        }


        private void SiteProvisioning_Load(object sender, EventArgs e)
        {
            Console.SetOut(new TextBoxWriter(txt_Console));
        }
        private void btn_Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void rdo_Publishing_CheckedChanged(object sender, EventArgs e)
        {
            if (rdo_Publishing.Checked)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = true;
                checkBox3.Checked = true;
            }
            else
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
            }
        }
        #endregion


        #region Provisioning
        private ProvisioningTemplate GetProvisioningTemplate(string webUrl, string userName, SecureString pwd)
        {
            try
            {
                Console.WriteLine(Constants.EXTRACT);
                using (var ctx = new ClientContext(webUrl))
                {
                    ctx.Credentials = new SharePointOnlineCredentials(userName, pwd);
                    ctx.RequestTimeout = Timeout.Infinite;

                    // Just to output the site details
                    Web web = ctx.Web;
                    ctx.Load(web, w => w.Title);
                    ctx.ExecuteQueryRetry();

                    ProvisioningTemplateCreationInformation ptci = new ProvisioningTemplateCreationInformation(ctx.Web);
                    // Create FileSystemConnector to store a temporary copy of the template 
                    ptci.FileConnector = new FileSystemConnector(Constants.LOCALPATH, "");

                    if (checkBox1.Checked)
                        ptci.PersistBrandingFiles = true;
                    if (checkBox2.Checked)
                        ptci.PersistPublishingFiles = true;
                    if (checkBox3.Checked)
                        ptci.IncludeNativePublishingFiles = true;
                    if (checkBox4.Checked)
                        ptci.IncludeSiteGroups = true;

                    if (checkBox5.Checked)
                        ptci.IncludeSiteCollectionTermGroup = true;
                    if (checkBox6.Checked)
                        ptci.IncludeSearchConfiguration = true;
                    if (checkBox7.Checked)
                        ptci.IncludeAllTermGroups = true;
                    if (checkBox8.Checked)
                        ptci.PersistMultiLanguageResources = true;

                    ptci.ProgressDelegate = delegate(String message, Int32 progress, Int32 total)
                    {
                        Console.WriteLine("Extracting {0:00} out of {1:00} - {2}", progress, total, message);
                    };
                    template = ctx.Web.GetProvisioningTemplate(ptci);

                    XMLTemplateProvider provider = new XMLFileSystemTemplateProvider(Constants.LOCALPATH, "");
                    provider.SaveAs(template, "PnPProvisioningasos.xml");
                }
                Console.WriteLine("Extract Completed");
                return template;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                EnableControls();
                return null;
            }
        }
        private bool ApplyProvisioningTemplate(string webUrl, string userName, SecureString pwd, ProvisioningTemplate template)
        {
            try
            {
                Console.WriteLine("Apply Web Template in targeting web");
                using (var ctx = new ClientContext(webUrl))
                {
                    ctx.Credentials = new SharePointOnlineCredentials(userName, pwd);
                    ctx.RequestTimeout = Timeout.Infinite;
                    Web web = ctx.Web;


                    ProvisioningTemplateApplyingInformation ptai = new ProvisioningTemplateApplyingInformation();

                    ptai.ProgressDelegate = delegate(String message, Int32 progress, Int32 total)
                    {
                        Console.WriteLine("Applying {0:00} out of {1:00} - {2}", progress, total, message);
                    };

                    FileSystemConnector connector = new FileSystemConnector(Constants.LOCALPATH, "");

                    //Remove Files section while site collection to Subsite and Subsite to Suibsite provisioning
                    if (srcPublish)
                    {
                        template.Files.RemoveAll(f => f.Overwrite.Equals(true));
                    }

                    template.Connector = connector;
                    web.ApplyProvisioningTemplate(template, ptai);
                }
                Console.WriteLine("Apply Web Template in targeting web site is Completed");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                EnableControls();
                return false;
            }

        }
        #endregion

        #region Functions
        public bool requiredFiedlValidator(string templateWebUrl, string targetWebUrl, string userName, string password)
        {
            if ((templateWebUrl == string.Empty) || (targetWebUrl == string.Empty) || (userName == string.Empty) || (password == string.Empty))
            {
                if (templateWebUrl == string.Empty)
                {
                    Console.WriteLine(Constants.TEMPLATEURL);
                }
                else if (targetWebUrl == string.Empty)
                {
                    Console.WriteLine(Constants.TARGETURL);
                }
                else if (userName == string.Empty)
                {
                    Console.WriteLine(Constants.USERNAME);
                }
                else if (password == string.Empty)
                {
                    Console.WriteLine(Constants.PASSWORD);
                }
                EnableControls();
                return false;
            }
            return true;
        }

        public bool ValidateUser(string templateWebUrl, string targetWebUrl, string userName, string password)
        {
            Console.WriteLine(Constants.VALIDATEUSER);

            if (!ValidateWebURLAccess(templateWebUrl, pwd, "src"))
            {
                Console.WriteLine(Constants.VALIDATETEMPLATEURL);
                EnableControls();
                return false;
            }
            if (!ValidateWebURLAccess(targetWebUrl, pwd, "target"))
            {
                Console.WriteLine(Constants.VALIDATETARGETURL);
                EnableControls();
                return false;
            }
            return true;
        }
        public void listAllListsandLibraries(string webUrl, string userName, SecureString pwd, out List<string> listnames, out List<string> librarynames, out List<string> sitepages)
        {
            listnames = new List<string>();
            librarynames = new List<string>();
            sitepages = new List<string>();
            using (var ctx = new ClientContext(webUrl))
            {
                ctx.Credentials = new SharePointOnlineCredentials(userName, pwd);
                ctx.RequestTimeout = Timeout.Infinite;
                ctx.Load(ctx.Web.Lists);
                ctx.ExecuteQuery();
                foreach (List list in ctx.Web.Lists)
                {
                    string basetype = list.BaseType.ToString();
                    string status = list.Hidden.ToString();
                    string baseTemplate = list.BaseTemplate.ToString();
                    //All Type of Lists
                    if ((basetype == "GenericList") && (status == "False"))
                    {
                        listnames.Add(list.Title);
                    }
                    //Site Pages Library
                    else if ((basetype == "DocumentLibrary") && (status == "False") && (baseTemplate == "119"))
                    {
                        sitepages.Add(list.Title);
                    }
                    //Pages Library
                    else if ((basetype == "DocumentLibrary") && (status == "False") && (baseTemplate == "850"))
                    {
                        sitepages.Add(list.Title);
                    }
                    else if ((basetype == "DocumentLibrary") && (status == "False"))
                    {
                        librarynames.Add(list.Title);
                    }                    
                }
            }
        }
        public void CloneListItems(string listname, string webUrl, string targetWebURL, string userName, SecureString pwd)
        {
            try
            {
                ListItemCollection listItemsFrom = null;
                using (var ctx = new ClientContext(webUrl))
                {
                    ctx.Credentials = new SharePointOnlineCredentials(userName, pwd);
                    ctx.RequestTimeout = Timeout.Infinite;

                    List _list = ctx.Web.Lists.GetByTitle(listname);
                    CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml = "<View/>";
                    listItemsFrom = _list.GetItems(camlQuery);
                    ctx.Load(listItemsFrom);
                    ctx.ExecuteQuery();
                }

                using (var ctx = new ClientContext(targetWebURL))
                {
                    ctx.Credentials = new SharePointOnlineCredentials(userName, pwd);
                    ctx.RequestTimeout = Timeout.Infinite;
                    List _targetlist = ctx.Web.Lists.GetByTitle(listname);

                    OSP.FieldCollection fields = _targetlist.Fields;
                    ctx.Load(fields);
                    ctx.ExecuteQuery();

                    foreach (ListItem item in listItemsFrom)
                    {
                        if (item.FileSystemObjectType == FileSystemObjectType.File)
                        {
                            bool isAttachment = false;
                            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                            ListItem newItem = _targetlist.AddItem(itemCreateInfo);

                            for (int i = 0; i < fields.Count; i++)
                            {
                                OSP.Field fieldTemp = fields[i];
                                string InternalName = fieldTemp.InternalName;
                                if ((!fieldTemp.ReadOnlyField) && (fieldTemp.InternalName != "Attachments") && (fieldTemp.InternalName != "ContentType"))
                                {
                                    newItem[InternalName] = item[InternalName];
                                }
                                else if ((fieldTemp.InternalName == "Attachments") && (item[InternalName].ToString() == "True"))
                                {
                                    isAttachment = true;
                                }
                            }
                            newItem.Update();
                            ctx.ExecuteQuery();
                            if (isAttachment)
                            {
                                ClientContext ctx1 = new ClientContext(templateWebUrl);
                                ctx1.Credentials = new SharePointOnlineCredentials(userName, pwd);
                                ctx1.RequestTimeout = Timeout.Infinite;

                                string src = string.Format("{0}/lists/{1}/Attachments/{2}", templateWebUrl, listname, item.Id);
                                OSP.Folder attFolder = ctx1.Web.GetFolderByServerRelativeUrl(src);
                                ctx1.Load(attFolder);
                                OSP.FileCollection attachments = attFolder.Files;
                                ctx1.Load(attachments);
                                ctx1.ExecuteQuery();

                                if (attachments.Count > 0)
                                {
                                    foreach (OSP.File attachment in attachments)
                                    {
                                        ctx1.Load(attachment);
                                        var clientResultStream = attachment.OpenBinaryStream();
                                        ctx1.ExecuteQuery();
                                        var stream = clientResultStream.Value;

                                        AttachmentCreationInformation attachFileInfo = new AttachmentCreationInformation();
                                        Byte[] buffer = new Byte[attachment.Length];
                                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                                        System.IO.MemoryStream stream2 = new System.IO.MemoryStream(buffer);
                                        attachFileInfo.ContentStream = stream2;
                                        attachFileInfo.FileName = attachment.Name;

                                        Attachment newitemattachment = newItem.AttachmentFiles.Add(attachFileInfo);
                                        ctx.Load(newitemattachment);
                                        ctx.ExecuteQuery();
                                        stream2.Close();
                                    }
                                }
                            }
                        }
                        else
                        {
                            //Required to write code later...
                            //Console.WriteLine("Folder not supported");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("does not exist at site with URL") == false)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public void CloneLibraryItems(string srcLibrary, string srcUrl, string destUrl, string userName, SecureString pwd)
        {
            string srclibraryname = string.Empty;
            string fileName = string.Empty;
            string folderPath = string.Empty;
            try
            {
                ClientContext srcContext = new ClientContext(srcUrl);
                ClientContext destContext = new ClientContext(destUrl);

                srcContext.Credentials = new SharePointOnlineCredentials(userName, pwd);
                srcContext.RequestTimeout = Timeout.Infinite;
                Web srcWeb = srcContext.Web;
                List srcList = srcWeb.Lists.GetByTitle(srcLibrary);
                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View Scope='RecursiveAll'></View>";
                ListItemCollection itemColl = srcList.GetItems(camlQuery);
                srcContext.Load(itemColl);
                srcContext.ExecuteQuery();

                destContext.Credentials = new SharePointOnlineCredentials(userName, pwd);
                destContext.RequestTimeout = Timeout.Infinite;
                Web destWeb = destContext.Web;
                destContext.Load(destWeb);
                destContext.ExecuteQuery();

                string _path = destWeb.ServerRelativeUrl;
                if (itemColl.Count > 0)
                {
                    srclibraryname = itemColl[0].FieldValues["FileDirRef"].ToString();
                    string[] srcurlSplit = srclibraryname.Split('/');
                    srclibraryname = srcurlSplit[srcurlSplit.Count() - 1];

                    foreach (ListItem doc in itemColl)
                    {
                        if (doc.FileSystemObjectType == FileSystemObjectType.File)
                        {
                            fileName = doc["FileRef"].ToString();
                            string[] fileNames = fileName.Split(new string[] { srclibraryname }, StringSplitOptions.None);
                            fileName = fileNames[fileNames.Count() - 1];

                            OSP.File file = doc.File;
                            srcContext.Load(file);
                            srcContext.ExecuteQuery();

                            FileInformation fileInfo = OSP.File.OpenBinaryDirect(srcContext, file.ServerRelativeUrl);
                            OSP.File.SaveBinaryDirect(destContext, _path + "/" + srclibraryname + fileName, fileInfo.Stream, true);
                        }
                        else if (doc.FileSystemObjectType == FileSystemObjectType.Folder)
                        {
                            folderPath = doc["FileRef"].ToString();
                            string[] fileNames = folderPath.Split(new string[] { srclibraryname }, StringSplitOptions.None);
                            folderPath = fileNames[fileNames.Count() - 1];
                            folderPath = folderPath.TrimStart(new Char[] { '/' });
                            //Console.WriteLine("Folder Path :" + folderPath);
                            OSP.Folder folder = CreateFolder(destContext.Web, srcLibrary, folderPath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("does not exist at site with URL") == false)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public void CloneSitePages(string srcUrl, string srcLibrary, string destUrl, string userName, SecureString pwd)
        {
            string srclibraryname = string.Empty;
            string fileName = string.Empty;
            string folderPath = string.Empty;
            int id = 0;
            try
            {
                ClientContext srcContext = new ClientContext(srcUrl);
                ClientContext destContext = new ClientContext(destUrl);

                srcContext.Credentials = new SharePointOnlineCredentials(userName, pwd);
                srcContext.RequestTimeout = Timeout.Infinite;
                Web srcWeb = srcContext.Web;
                List srcList = srcWeb.Lists.GetByTitle(srcLibrary);
                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View Scope='RecursiveAll'></View>";
                ListItemCollection itemColl = srcList.GetItems(camlQuery);
                srcContext.Load(itemColl);
                OSP.FieldCollection fields = srcList.Fields;
                srcContext.Load(fields);
                srcContext.ExecuteQuery();

                destContext.Credentials = new SharePointOnlineCredentials(userName, pwd);
                destContext.RequestTimeout = Timeout.Infinite;
                Web destWeb = destContext.Web;
                destContext.Load(destWeb);
                destContext.ExecuteQuery();

                string _path = destWeb.ServerRelativeUrl;
                if (itemColl.Count > 0)
                {
                    srclibraryname = itemColl[0].FieldValues["FileDirRef"].ToString();
                    string[] srcurlSplit = srclibraryname.Split('/');
                    srclibraryname = srcurlSplit[srcurlSplit.Count() - 1];

                    foreach (ListItem doc in itemColl)
                    {
                        if (doc.FileSystemObjectType == FileSystemObjectType.File)
                        {
                            fileName = doc["FileRef"].ToString();
                            string[] fileNames = fileName.Split(new string[] { srclibraryname }, StringSplitOptions.None);
                            fileName = fileNames[fileNames.Count() - 1];

                            OSP.File file = doc.File;
                            srcContext.Load(file);
                            srcContext.ExecuteQuery();

                            FileInformation fileInfo = OSP.File.OpenBinaryDirect(srcContext, file.ServerRelativeUrl);

                            string serverRelevantUrl = _path + "/" + srclibraryname + fileName;
                            Microsoft.SharePoint.Client.File.SaveBinaryDirect(destContext, serverRelevantUrl, fileInfo.Stream, true);
                            Microsoft.SharePoint.Client.File spfile = destContext.Web.GetFileByServerRelativeUrl(serverRelevantUrl);
                            ListItem item = spfile.ListItemAllFields;
                            destContext.Load(item);
                            destContext.ExecuteQuery();
                            id = item.Id;

                            //Get all webparts from the page
                            OSP.WebParts.LimitedWebPartManager limitedWebPartManager = file.GetLimitedWebPartManager(OSP.WebParts.PersonalizationScope.Shared);
                            srcContext.Load(limitedWebPartManager.WebParts, f => f.Include(s => s.WebPart.Properties, s => s.WebPart.Title, s => s.WebPart.ZoneIndex, s => s.Id));
                            srcContext.ExecuteQuery();

                            if (limitedWebPartManager.WebParts.Count > 0)
                            {
                                for (int w = 0; w < limitedWebPartManager.WebParts.Count; w++)
                                {
                                    OSP.WebParts.WebPartDefinition oWebPartDefinition = limitedWebPartManager.WebParts[w];
                                    OSP.WebParts.WebPart oWebPart = oWebPartDefinition.WebPart;
                                    OSP.PropertyValues props = oWebPart.Properties;

                                    string ExportMode = oWebPartDefinition.WebPart.Properties.FieldValues["ExportMode"].ToString();
                                    //foreach (KeyValuePair<string, object> field in props.FieldValues.ToList())
                                    //{
                                    //    if (field.Key == "ExportMode")
                                    //    {
                                    //        ExportMode = field.Value.ToString();
                                    //        break;
                                    //    }
                                    //}
                                    if (ExportMode == "1")
                                    {

                                        ClientResult<string> webPartXmlData = limitedWebPartManager.ExportWebPart(oWebPartDefinition.Id);
                                        srcContext.Load(oWebPartDefinition, f => f.ZoneId);
                                        srcContext.ExecuteQuery();
                                        var webPartXml = webPartXmlData.Value;

                                        var page = destContext.Web.GetFileByServerRelativeUrl(serverRelevantUrl);
                                        OSP.WebParts.LimitedWebPartManager deslimitedWebPartManager = page.GetLimitedWebPartManager(OSP.WebParts.PersonalizationScope.Shared);
                                        OSP.WebParts.WebPartDefinition desWebPartDefinition = deslimitedWebPartManager.ImportWebPart(webPartXml);
                                        if (oWebPartDefinition.ZoneId == "wpz")
                                        {
                                            OSP.WebParts.WebPartDefinition newWebPartDefinition = deslimitedWebPartManager.AddWebPart(desWebPartDefinition.WebPart, "Header", oWebPartDefinition.WebPart.ZoneIndex);
                                        }
                                        else
                                        {
                                            OSP.WebParts.WebPartDefinition newWebPartDefinition = deslimitedWebPartManager.AddWebPart(desWebPartDefinition.WebPart, oWebPartDefinition.ZoneId, oWebPartDefinition.WebPart.ZoneIndex);
                                        }
                                        destContext.ExecuteQuery();
                                    }
                                }
                            }
                            //Console.WriteLine("Webparts Added");

                            //update the properties to the current page
                            OSP.List oList = destContext.Web.Lists.GetByTitle(srcLibrary);
                            ListItem oListItem = oList.GetItemById(id);

                            for (int i = 0; i < fields.Count; i++)
                            {
                                OSP.Field fieldTemp = fields[i];
                                string InternalName = fieldTemp.InternalName;
                                if ((!fieldTemp.ReadOnlyField) && (fieldTemp.InternalName != "Attachments") && (fieldTemp.InternalName != "ContentType"))
                                {
                                    oListItem[InternalName] = doc[InternalName];
                                }
                            }

                            oListItem.Update();
                            destContext.ExecuteQuery();
                            //Publish the page
                            if (targetPublish)
                            {
                                oListItem.File.CheckIn("Migrated", CheckinType.MajorCheckIn);
                                oListItem.File.Publish("Migrated");
                                destContext.ExecuteQuery();
                            }
                        }
                        else if (doc.FileSystemObjectType == FileSystemObjectType.Folder)
                        {
                            folderPath = doc["FileRef"].ToString();
                            string[] fileNames = folderPath.Split(new string[] { srclibraryname }, StringSplitOptions.None);
                            folderPath = fileNames[fileNames.Count() - 1];
                            folderPath = folderPath.TrimStart(new Char[] { '/' });
                            var folder = CreateFolder(destContext.Web, srcLibrary, folderPath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("does not exist at site with URL") == false)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        public OSP.Folder CreateFolder(Web web, string listTitle, string fullFolderPath)
        {
            if (string.IsNullOrEmpty(fullFolderPath))
                throw new ArgumentNullException("fullFolderPath");
            var list = web.Lists.GetByTitle(listTitle);
            return CreateFolderInternal(web, list.RootFolder, fullFolderPath);
        }

        private OSP.Folder CreateFolderInternal(Web web, OSP.Folder parentFolder, string fullFolderPath)
        {
            var folderUrls = fullFolderPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            string folderUrl = folderUrls[0];
            var curFolder = parentFolder.Folders.Add(folderUrl);
            web.Context.Load(curFolder);
            web.Context.ExecuteQuery();

            if (folderUrls.Length > 1)
            {
                var folderPath = string.Join("/", folderUrls, 1, folderUrls.Length - 1);
                return CreateFolderInternal(web, curFolder, folderPath);
            }
            return curFolder;
        }
        private bool ValidateWebURLAccess(string webUrl, SecureString pwd, string _type)
        {
            bool status = true;
            try
            {
                using (var ctx = new ClientContext(webUrl))
                {
                    ctx.Credentials = new SharePointOnlineCredentials(userName, pwd);
                    ctx.RequestTimeout = Timeout.Infinite;

                    // Just to output the site details
                    Web web = ctx.Web;
                    ctx.Load(web);
                    ctx.ExecuteQueryRetry();

                    bool isPublish = IsPublishingWeb(web);
                    if (_type == "src")
                    {
                        srcPublish = isPublish;
                        if (isPublish)
                            rdo_Publishing.Checked = true;
                    }
                    else if (_type == "target")
                    {
                        targetPublish = isPublish;
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = false;
            }
            return status;
        }

        public static bool IsPublishingWeb(Web web)
        {
            var ctx = web.Context;
            var propName = "__PublishingFeatureActivated";
            //Ensure web properties are loaded
            if (!web.IsObjectPropertyInstantiated("AllProperties"))
            {
                ctx.Load(web, w => w.AllProperties);
                ctx.ExecuteQuery();
            }
            //Verify whether publishing feature is activated 
            if (web.AllProperties.FieldValues.ContainsKey(propName))
            {
                bool propVal;
                Boolean.TryParse((string)web.AllProperties[propName], out propVal);
                return propVal;
            }
            return false;
        }
        private void DisableControls()
        {
            btn_Close.Enabled = false;
            btn_extractApply.Enabled = false;
            panel1.Enabled = false;
        }
        private void EnableControls()
        {
            btn_Close.Enabled = true;
            btn_extractApply.Enabled = true;
            panel1.Enabled = true;
        }
        #endregion


       

        
    }
}
