﻿namespace Jenkins.SP.Migration
{
    partial class SiteProvisioning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
                base.Dispose(disposing);
            }
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Panel panel5;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SiteProvisioning));
            this.chk_includePages = new System.Windows.Forms.CheckBox();
            this.lbl_targetSiteType = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdo_Publishing = new System.Windows.Forms.RadioButton();
            this.rdo_teamsite = new System.Windows.Forms.RadioButton();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.chk_includeLibraries = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chk_IncludeLists = new System.Windows.Forms.CheckBox();
            this.targetWebURL = new System.Windows.Forms.TextBox();
            this.chk_siteProvisioning = new System.Windows.Forms.CheckBox();
            this.webUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_srcSiteType = new System.Windows.Forms.Label();
            this.btn_extractApply = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Console = new System.Windows.Forms.TextBox();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_UserName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_Close = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            panel5 = new System.Windows.Forms.Panel();
            panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel5
            // 
            panel5.Controls.Add(this.chk_includePages);
            panel5.Controls.Add(this.lbl_targetSiteType);
            panel5.Controls.Add(this.panel2);
            panel5.Controls.Add(this.chk_includeLibraries);
            panel5.Controls.Add(this.label2);
            panel5.Controls.Add(this.chk_IncludeLists);
            panel5.Controls.Add(this.targetWebURL);
            panel5.Controls.Add(this.chk_siteProvisioning);
            panel5.Controls.Add(this.webUrl);
            panel5.Controls.Add(this.label1);
            panel5.Controls.Add(this.label8);
            panel5.Controls.Add(this.label7);
            panel5.Controls.Add(this.lbl_srcSiteType);
            panel5.Controls.Add(this.btn_extractApply);
            panel5.ForeColor = System.Drawing.Color.Black;
            panel5.Location = new System.Drawing.Point(0, 148);
            panel5.Name = "panel5";
            panel5.Size = new System.Drawing.Size(401, 379);
            panel5.TabIndex = 51;
            // 
            // chk_includePages
            // 
            this.chk_includePages.AutoSize = true;
            this.chk_includePages.Checked = true;
            this.chk_includePages.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_includePages.Location = new System.Drawing.Point(213, 283);
            this.chk_includePages.Name = "chk_includePages";
            this.chk_includePages.Size = new System.Drawing.Size(134, 17);
            this.chk_includePages.TabIndex = 57;
            this.chk_includePages.Text = "Include Pages Content";
            this.chk_includePages.UseVisualStyleBackColor = true;
            // 
            // lbl_targetSiteType
            // 
            this.lbl_targetSiteType.AutoSize = true;
            this.lbl_targetSiteType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_targetSiteType.ForeColor = System.Drawing.Color.Coral;
            this.lbl_targetSiteType.Location = new System.Drawing.Point(7, 170);
            this.lbl_targetSiteType.Name = "lbl_targetSiteType";
            this.lbl_targetSiteType.Size = new System.Drawing.Size(0, 13);
            this.lbl_targetSiteType.TabIndex = 46;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.checkBox8);
            this.panel2.Controls.Add(this.checkBox2);
            this.panel2.Controls.Add(this.checkBox7);
            this.panel2.Controls.Add(this.checkBox3);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.checkBox4);
            this.panel2.Controls.Add(this.checkBox5);
            this.panel2.Controls.Add(this.checkBox6);
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(9, 196);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 118);
            this.panel2.TabIndex = 44;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(3, 52);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(126, 17);
            this.checkBox1.TabIndex = 13;
            this.checkBox1.Text = "Persist Branding Files";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(217, 33);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(187, 17);
            this.checkBox8.TabIndex = 28;
            this.checkBox8.Text = "Persist Multi Language Resources";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(3, 74);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(132, 17);
            this.checkBox2.TabIndex = 14;
            this.checkBox2.Text = "Persist Publishing Files";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(408, 33);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(139, 17);
            this.checkBox7.TabIndex = 27;
            this.checkBox7.Text = "Include All Term Groups";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(3, 96);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(170, 17);
            this.checkBox3.TabIndex = 15;
            this.checkBox3.Text = "Include Native Publishing Files";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdo_Publishing);
            this.panel1.Controls.Add(this.rdo_teamsite);
            this.panel1.Location = new System.Drawing.Point(3, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(189, 25);
            this.panel1.TabIndex = 26;
            // 
            // rdo_Publishing
            // 
            this.rdo_Publishing.AutoSize = true;
            this.rdo_Publishing.Location = new System.Drawing.Point(83, 3);
            this.rdo_Publishing.Name = "rdo_Publishing";
            this.rdo_Publishing.Size = new System.Drawing.Size(99, 17);
            this.rdo_Publishing.TabIndex = 24;
            this.rdo_Publishing.Text = "Publishing Sites";
            this.rdo_Publishing.UseVisualStyleBackColor = true;
            this.rdo_Publishing.CheckedChanged += new System.EventHandler(this.rdo_Publishing_CheckedChanged);
            // 
            // rdo_teamsite
            // 
            this.rdo_teamsite.AutoSize = true;
            this.rdo_teamsite.Checked = true;
            this.rdo_teamsite.Location = new System.Drawing.Point(3, 3);
            this.rdo_teamsite.Name = "rdo_teamsite";
            this.rdo_teamsite.Size = new System.Drawing.Size(77, 17);
            this.rdo_teamsite.TabIndex = 25;
            this.rdo_teamsite.TabStop = true;
            this.rdo_teamsite.Text = "Other Sites";
            this.rdo_teamsite.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(408, 57);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(119, 17);
            this.checkBox4.TabIndex = 16;
            this.checkBox4.Text = "Include Site Groups";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(217, 56);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(190, 17);
            this.checkBox5.TabIndex = 17;
            this.checkBox5.Text = "Include Site Collection Term Group";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(217, 79);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(163, 17);
            this.checkBox6.TabIndex = 18;
            this.checkBox6.Text = "Include Search Configuration";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // chk_includeLibraries
            // 
            this.chk_includeLibraries.AutoSize = true;
            this.chk_includeLibraries.Checked = true;
            this.chk_includeLibraries.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_includeLibraries.Location = new System.Drawing.Point(213, 256);
            this.chk_includeLibraries.Name = "chk_includeLibraries";
            this.chk_includeLibraries.Size = new System.Drawing.Size(143, 17);
            this.chk_includeLibraries.TabIndex = 56;
            this.chk_includeLibraries.Text = "Include Libraries Content";
            this.chk_includeLibraries.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(6, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Target Web URL";
            // 
            // chk_IncludeLists
            // 
            this.chk_IncludeLists.AutoSize = true;
            this.chk_IncludeLists.Checked = true;
            this.chk_IncludeLists.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_IncludeLists.Location = new System.Drawing.Point(213, 230);
            this.chk_IncludeLists.Name = "chk_IncludeLists";
            this.chk_IncludeLists.Size = new System.Drawing.Size(125, 17);
            this.chk_IncludeLists.TabIndex = 55;
            this.chk_IncludeLists.Text = "Include Lists Content";
            this.chk_IncludeLists.UseVisualStyleBackColor = true;
            // 
            // targetWebURL
            // 
            this.targetWebURL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.targetWebURL.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.targetWebURL.ForeColor = System.Drawing.Color.DodgerBlue;
            this.targetWebURL.Location = new System.Drawing.Point(9, 120);
            this.targetWebURL.Name = "targetWebURL";
            this.targetWebURL.Size = new System.Drawing.Size(375, 23);
            this.targetWebURL.TabIndex = 3;
            // 
            // chk_siteProvisioning
            // 
            this.chk_siteProvisioning.AutoSize = true;
            this.chk_siteProvisioning.Checked = true;
            this.chk_siteProvisioning.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_siteProvisioning.Enabled = false;
            this.chk_siteProvisioning.Location = new System.Drawing.Point(213, 207);
            this.chk_siteProvisioning.Name = "chk_siteProvisioning";
            this.chk_siteProvisioning.Size = new System.Drawing.Size(104, 17);
            this.chk_siteProvisioning.TabIndex = 54;
            this.chk_siteProvisioning.Text = "Site Provisioning";
            this.chk_siteProvisioning.UseVisualStyleBackColor = true;
            // 
            // webUrl
            // 
            this.webUrl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.webUrl.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.webUrl.ForeColor = System.Drawing.Color.DodgerBlue;
            this.webUrl.Location = new System.Drawing.Point(9, 28);
            this.webUrl.Name = "webUrl";
            this.webUrl.Size = new System.Drawing.Size(375, 23);
            this.webUrl.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Source URL";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label8.Location = new System.Drawing.Point(6, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(290, 13);
            this.label8.TabIndex = 50;
            this.label8.Text = "Ex: https://jenkinsns.sharepoint.com/sites/Dev/TS/Subsit2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label7.Location = new System.Drawing.Point(9, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(308, 13);
            this.label7.TabIndex = 49;
            this.label7.Text = "Ex: Ex: https://jenkinsns.sharepoint.com/sites/Dev/TS/Subsit1";
            // 
            // lbl_srcSiteType
            // 
            this.lbl_srcSiteType.AutoSize = true;
            this.lbl_srcSiteType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_srcSiteType.ForeColor = System.Drawing.Color.Coral;
            this.lbl_srcSiteType.Location = new System.Drawing.Point(10, 76);
            this.lbl_srcSiteType.Name = "lbl_srcSiteType";
            this.lbl_srcSiteType.Size = new System.Drawing.Size(0, 13);
            this.lbl_srcSiteType.TabIndex = 45;
            // 
            // btn_extractApply
            // 
            this.btn_extractApply.AutoEllipsis = true;
            this.btn_extractApply.BackColor = System.Drawing.Color.White;
            this.btn_extractApply.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_extractApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_extractApply.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_extractApply.ForeColor = System.Drawing.Color.Transparent;
            this.btn_extractApply.Image = ((System.Drawing.Image)(resources.GetObject("btn_extractApply.Image")));
            this.btn_extractApply.Location = new System.Drawing.Point(140, 316);
            this.btn_extractApply.Name = "btn_extractApply";
            this.btn_extractApply.Size = new System.Drawing.Size(101, 57);
            this.btn_extractApply.TabIndex = 4;
            this.btn_extractApply.UseVisualStyleBackColor = false;
            this.btn_extractApply.Click += new System.EventHandler(this.btn_extractApply_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Forte", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Coral;
            this.label5.Location = new System.Drawing.Point(407, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 30);
            this.label5.TabIndex = 43;
            this.label5.Text = "Status log";
            // 
            // txt_Console
            // 
            this.txt_Console.BackColor = System.Drawing.Color.White;
            this.txt_Console.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Console.ForeColor = System.Drawing.Color.Coral;
            this.txt_Console.Location = new System.Drawing.Point(401, 187);
            this.txt_Console.Multiline = true;
            this.txt_Console.Name = "txt_Console";
            this.txt_Console.ReadOnly = true;
            this.txt_Console.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_Console.Size = new System.Drawing.Size(385, 587);
            this.txt_Console.TabIndex = 5;
            // 
            // txt_Password
            // 
            this.txt_Password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Password.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_Password.Location = new System.Drawing.Point(93, 71);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.PasswordChar = '*';
            this.txt_Password.Size = new System.Drawing.Size(233, 23);
            this.txt_Password.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label3.Location = new System.Drawing.Point(17, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 14);
            this.label3.TabIndex = 38;
            this.label3.Text = "Password";
            // 
            // txt_UserName
            // 
            this.txt_UserName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_UserName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_UserName.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_UserName.Location = new System.Drawing.Point(93, 40);
            this.txt_UserName.Name = "txt_UserName";
            this.txt_UserName.Size = new System.Drawing.Size(233, 23);
            this.txt_UserName.TabIndex = 0;
            this.txt_UserName.Text = "jenkins.ns@domain.com";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label4.Location = new System.Drawing.Point(17, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 14);
            this.label4.TabIndex = 36;
            this.label4.Text = "User Name";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.btn_Close);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(-1, -1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(787, 30);
            this.panel3.TabIndex = 47;
            // 
            // btn_Close
            // 
            this.btn_Close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Close.BackgroundImage")));
            this.btn_Close.FlatAppearance.BorderSize = 0;
            this.btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Close.Location = new System.Drawing.Point(756, 0);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(31, 27);
            this.btn_Close.TabIndex = 58;
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(136, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(511, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "Extract and Migrate Office 365 SharePoint Sites";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.txt_UserName);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.txt_Password);
            this.panel4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(58, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(343, 109);
            this.panel4.TabIndex = 48;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(89, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 23);
            this.label6.TabIndex = 40;
            this.label6.Text = "Login";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Location = new System.Drawing.Point(0, 136);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(786, 15);
            this.panel7.TabIndex = 53;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 109);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Location = new System.Drawing.Point(0, 527);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(401, 15);
            this.panel6.TabIndex = 54;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 542);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Coral;
            this.label10.Location = new System.Drawing.Point(49, 560);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 15);
            this.label10.TabIndex = 56;
            this.label10.Text = "Steps Involved";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label11.Location = new System.Drawing.Point(57, 590);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(323, 13);
            this.label11.TabIndex = 57;
            this.label11.Text = "1. Extract the Source Site - i.e.. Extract as XML Template";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label12.Location = new System.Drawing.Point(57, 617);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(211, 13);
            this.label12.TabIndex = 58;
            this.label12.Text = "2. Apply the Template to Target site";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label13.Location = new System.Drawing.Point(81, 641);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(266, 13);
            this.label13.TabIndex = 59;
            this.label13.Text = "i.e.. List Instance, Content types, Site columns";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label14.Location = new System.Drawing.Point(57, 673);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(156, 13);
            this.label14.TabIndex = 60;
            this.label14.Text = "3. Migrate all List contents";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label15.Location = new System.Drawing.Point(57, 698);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(176, 13);
            this.label15.TabIndex = 61;
            this.label15.Text = "4. Migrate all Library contents";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label16.Location = new System.Drawing.Point(57, 722);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(341, 13);
            this.label16.TabIndex = 62;
            this.label16.Text = "5. Migrate all Pages/SitePages contents including webparts";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(81, 753);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(186, 13);
            this.label17.TabIndex = 63;
            this.label17.Text = "* List View Web parts – unsupported ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Location = new System.Drawing.Point(447, 37);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(298, 80);
            this.pictureBox3.TabIndex = 64;
            this.pictureBox3.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label18.Location = new System.Drawing.Point(102, 658);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(296, 13);
            this.label18.TabIndex = 65;
            this.label18.Text = "Create Lists, Libraries, apply themes, master pages";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(-1, 4);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 13);
            this.label19.TabIndex = 29;
            this.label19.Text = "Auto Update";
            // 
            // SiteProvisioning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(786, 775);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel7);
            this.Controls.Add(panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txt_Console);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pictureBox3);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SiteProvisioning";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jenkins Office 365 SharePoint Migration Suite (Preview)";
            this.Load += new System.EventHandler(this.SiteProvisioning_Load);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_targetSiteType;
        private System.Windows.Forms.Label lbl_srcSiteType;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdo_Publishing;
        private System.Windows.Forms.RadioButton rdo_teamsite;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Console;
        private System.Windows.Forms.Button btn_extractApply;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_UserName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox targetWebURL;
        private System.Windows.Forms.TextBox webUrl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox chk_siteProvisioning;
        private System.Windows.Forms.CheckBox chk_IncludeLists;
        private System.Windows.Forms.CheckBox chk_includeLibraries;
        private System.Windows.Forms.CheckBox chk_includePages;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
    }
}

