﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Jenkins.SP.Migration
{
    public class Constants
    {
        public const string TEMPLATEURL = "Please enter Source Web Url";
        public const string TARGETURL = "Please enter Target Web Url";
        public const string USERNAME = "Please enter User Name";
        public const string PASSWORD = "Please enter Password";
        public const string VALIDATEUSER = "Validating User Credentials";
        public const string VALIDATETEMPLATEURL = "Please verify template site user credencials or Permission";
        public const string VALIDATETARGETURL = "Please verify TARGET site user credencials or Permission";
        public const string EXTRACT = "Extract Web Template";
        public const string LOCALPATH = @"c:\temp\pnpprovisioningasos";
    }

    public class TextBoxWriter : TextWriter
    {
        TextBox _output = null;

        public TextBoxWriter(TextBox output)
        {
            _output = output;
        }

        public override void Write(char value)
        {
            base.Write(value);
            _output.AppendText(value.ToString());
        }

        public override Encoding Encoding
        {
            get { return System.Text.Encoding.UTF8; }
        }
    }
}
